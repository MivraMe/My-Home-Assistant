Thank you for supporting me by downloading these blueprints.

Read the release notes and breaking changes on: https://github.com/smarthomejunkie/Ulanzi-Awtrix-BluePrints/blob/main/README.md#updates

You will find the instructions on how to install and use these blueprints in this video: https://youtu.be/N0NKPJzGHuA
View the manual at: https://github.com/smarthomejunkie/Ulanzi-Awtrix-BluePrints/

Note:
After uploading the Blueprints, go to Developer Tools > YAML tab and click AUTOMATIONS
Don't forget to create a toggle (or number) helper for each automation that you create with these Blueprints!

==========

Please consider supporting me monthly on Patreon, Ko-Fi, or by joining my channel:

If you become a member on Ko-Fio you will get a permanent discount on all the shop items!

* Join my channel to get access to perks: 📺 https://www.youtube.com/c/smarthomejunkie/join
* Please consider becoming my patron 🏅 at https://www.patreon.com/join/smarthomejunkie
* Or please support me by buying me a ☕ at https://ko-fi.com/smarthomejunkie/

These Blueprint are (c) copyright 2024 by Smart Home Junkie. You may not copy, reproduce, distribute, transmit, modify, create derivative works, or in any other way exploit any part of copyrighted material without the prior written permission from Smart Home Junkie
 
